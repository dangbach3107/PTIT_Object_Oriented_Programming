package J05044;

public class NhanVien {
    private String hoTen, chucVu, maNV;
    private long luongCoBan, soNgayCong, phuCapChucVu, luong, tamUng, conlai;
    private static int count = 0;
    public NhanVien(String hoTen, String chucVu, long luongCoBan, long soNgayCong) {
        maNV = String.format("NV%02d", ++count);
        this.hoTen = hoTen;
        this.chucVu = chucVu;
        this.luongCoBan = luongCoBan;
        this.soNgayCong = soNgayCong;
        phuCapChucVu = 100;
        if(chucVu.equals("GD")) phuCapChucVu = 500;
        else if(chucVu.equals("PGD")) phuCapChucVu = 400;
        else if(chucVu.equals("TP")) phuCapChucVu = 300;
        else if(chucVu.equals("KT")) phuCapChucVu = 250;

        luong = luongCoBan * soNgayCong;
        if((phuCapChucVu + luong) < 25000) {
            tamUng = Math.round((phuCapChucVu + luong) * 2.0f / 3 / 1000) * 1000;
        }
        else tamUng = 25000;
        conlai = luong + phuCapChucVu - tamUng;

    }
    @Override
    public String toString() {
        return maNV + " " + hoTen + " " + phuCapChucVu + " " + luong + " " + tamUng + " " + conlai;
    }
    public String getChucVu() {
        return chucVu;
    }
}
