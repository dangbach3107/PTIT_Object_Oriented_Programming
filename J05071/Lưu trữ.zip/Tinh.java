package J05071;

public class Tinh {
    private String maVung, ten;
    private long giaCuoc;
    public Tinh(String maVung, String ten, long giaCuoc) {
        this.maVung = maVung;
        this.ten = ten;
        this.giaCuoc = giaCuoc;
    }
    public String getMaVung() {
        return maVung;
    }
    public String getTen() {
        return ten;
    }
    public long getGiaCuoc() {
        return giaCuoc;
    }
    
}
