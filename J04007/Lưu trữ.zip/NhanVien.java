/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package j04007;

/**
 *
 * @author dangbach
 */
import java.util.*;

public class NhanVien {
    private String maNV, ten, gioiTinh, ngaySinh, diaChi, maSoThue, kiHopDong;
    
    public NhanVien (String maNV,String ten,String gioiTinh,String ngaySinh,String diaChi,String maSoThue,String kiHopDong){
        this.maNV = maNV;
        this.ten = ten;
        this.gioiTinh = gioiTinh;
        this.ngaySinh = ngaySinh;
        this.diaChi = diaChi;
        this.maSoThue = maSoThue;
        this.kiHopDong = kiHopDong;
    }
    
    public String toString(){
        return maNV + " " +  ten + " " + gioiTinh + " " +  ngaySinh + " " +  diaChi + " " +  maSoThue + " " + kiHopDong;
    }
}
