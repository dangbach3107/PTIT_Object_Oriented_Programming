package J05004;

public class SinhVien {
    private String ten, lop, ngaySinh, maSV;
    private double gpa;
    public SinhVien(String ten, String lop, String ngaySinh, double gpa) {
        String [] tach = ten.toLowerCase().split("\\s+");
        StringBuilder formatName = new StringBuilder();
        for(String thanhPhan : tach){
            formatName.append(Character.toUpperCase(thanhPhan.charAt(0))).append(thanhPhan.substring(1)).append(" ");
        }
        this.ten = formatName.toString().trim();

        this.lop = lop;
        
        String [] tmp = ngaySinh.split("/");
        this.ngaySinh = String.format("%02d/%02d/%s", Integer.parseInt(tmp[0]), Integer.parseInt(tmp[1]), tmp[2]);
        this.gpa = gpa;
    }
    public void setMaSV(int t) {
        this.maSV = String.format("B20DCCN%03d", t + 1);
    }
    @Override
    public String toString() {
        return maSV + " " + ten + " " + lop + " " + ngaySinh + " " + String.format("%.2f", gpa);
    }
    
}
