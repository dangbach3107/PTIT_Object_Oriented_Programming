package j04003;
/*
 * @author dangbach
 * 07/09/2024
 * 14:45
 */

import java.util.*;

public class Main {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);    

        PhanSo a = new PhanSo(in.nextLong(), in.nextLong());
        System.out.println(a);
    }
}
